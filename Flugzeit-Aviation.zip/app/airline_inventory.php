<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class airline_inventory extends Model
{
    protected $table="airline_inventory";
    protected $primaryKey="id_airline_inventory";



}
