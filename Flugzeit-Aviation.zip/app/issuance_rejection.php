<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class issuance_rejection extends Model
{
    protected $table = 'issuance_rejection';
    protected $primaryKey = 'id_issuance_rejection';
}
