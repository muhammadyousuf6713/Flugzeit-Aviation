<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class department_service extends Model
{
    protected $primarykey = "id_department_services";
}
