<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class role_permission extends Model
{
    protected $table = 'role_permission';
    protected $primaryKey = 'id_role_permission';
}
