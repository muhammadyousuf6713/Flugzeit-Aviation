<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class department_sub_service extends Model
{
    protected $primarykey = "id_department_sub_services";

}
