<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class follow_up_type extends Model
{
    protected $primaryKey="id_follow_up_types";
}
