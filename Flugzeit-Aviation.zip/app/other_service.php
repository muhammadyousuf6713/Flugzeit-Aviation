<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class other_service extends Model
{
    protected $table = "other_services";
    protected $primaryKey = "id_other_services";
}
