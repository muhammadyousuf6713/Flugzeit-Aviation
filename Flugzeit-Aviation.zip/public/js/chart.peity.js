$(function(){
  'use strict'

  // Line chart
  $('.peity-line').peity('line');

  // Bar charts
  $('.peity-bar').peity('bar');

  // Pie chart
  $('.peity-pie').peity('pie');

  // Donut chart
  $('.peity-donut').peity('donut');

  // Bar chart is already initialized found in bracket.js
});
