<link rel="stylesheet" href="{{ asset('/css/azia.css') }}">
<link href="{{ asset('/lib/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/ionicons/css/ionicons.min.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/typicons.font/typicons.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/spectrum-colorpicker/spectrum.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/select2/css/select2.min.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/ion-rangeslider/css/ion.rangeSlider.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/ion-rangeslider/css/ion.rangeSlider.skinFlat.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/amazeui-datetimepicker/css/amazeui.datetimepicker.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/jquery-simple-datetimepicker/jquery.simple-dtpicker.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/pickerjs/picker.min.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/datatables.net-dt/css/jquery.dataTables.min.css') }}" rel="stylesheet">
<link href="{{ asset('/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}" rel="stylesheet">

<!--<link rel="stylesheet "href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css"/>-->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="
https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css
" rel="stylesheet">


<link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
{{-- toastr css --}}
<style type="text/css">
     @import url('https://fonts.googleapis.com/css?family=Assistant');

    body {
        background: whitesmoke;
        font-family: Assistant, sans-serif;
    }

    button {
        background-color: darkslategrey;
        color: white;
        border: 0;
        font-size: 18px;
        font-weight: 500;
        border-radius: 7px;
        padding: 10px 10px;
        cursor: pointer;
        white-space: nowrap;
    }

    #success {
        background: green;
    }

    #error {
        background: red;
    }

    #warning {
        background: coral;
    }

    #info {
        background: cornflowerblue;
    }

    #question {
        background: grey;
    }
</style>
